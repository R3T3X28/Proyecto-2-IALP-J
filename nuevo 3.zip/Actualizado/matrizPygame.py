import pygame, sys, math
from tablero import tableroNiv1, tableroNiv2
from PacmanBase import *

pygame.init()
pantalla = pygame.display.set_mode((650, 720))
pygame.display.set_caption("Ejemplo de matriz en Pygame")
reloj = pygame.time.Clock()

# Los valores que definen las dimensiones de las casillas
ANCHO = 18
ALTO = 18
listaPuntosBlancos = []

juego = Juego(1,0,tableroNiv1,0)
matriz = juego.tablero

# Dibujar la matriz. Esta funcion se corre dentro del game loop para actualizar el tablero
def dibujarMatriz():
    for fila in range(40):
        for columna in range(36):
            if matriz[fila][columna] == 50:
                pygame.draw.line(pantalla, "pink", (columna*ANCHO, fila*ALTO+9), (columna*ANCHO+18, fila*ALTO+9), 4)
            if matriz[fila][columna] == 27: #Pieza Conector T270
                pantalla.blit(imgPiezaT270, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 26: #Pieza Conector T180
                pantalla.blit(imgPiezaT180, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 25: #Pieza Conector T90
                pantalla.blit(imgPiezaT90, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 24: #Pieza Conector T
                pantalla.blit(imgPiezaT, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 23: #Pieza Conector Oeste-Este
                pantalla.blit(imgPiezaConec_OE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 22: #Pieza Conector Sur-Oeste
                pantalla.blit(imgPiezaConec_SO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 21: #Pieza Conector Sur-Este
                pantalla.blit(imgPiezaConec_SE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 20: #Pieza Conector Norte-Oeste
                pantalla.blit(imgPiezaConec_NO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 19: #Pieza Conector Norte-Este
                pantalla.blit(imgPiezaConec_NE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 18: #Pieza Conector Norte-Sur
                pantalla.blit(imgPiezaConec_NS, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 17: #Pieza Derecha
                pantalla.blit(imgPiezaDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 16: #Pieza Izquierda
                pantalla.blit(imgPiezaIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 15: #Pierza Inferior
                pantalla.blit(imgPiezaInf, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 14: #Pieza Superior
                pantalla.blit(imgPiezaSup, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 13: # esquina superior derecha
                pantalla.blit(imgBordeEsq2InfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 12: # esquina superior izquierda
                pantalla.blit(imgBordeEsq2SupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 11: # esquina inferior derecha
                pantalla.blit(imgBordeEsq2SupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 10: # esquina inferior izquierda
                pantalla.blit(imgBordeEsq2InfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 9: # linea vertical Oeste
                pantalla.blit(imgBordeOes, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 8: # linea horizontal Este
                pantalla.blit(imgBordeEst, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 7: # linea horizontal Sur
                pantalla.blit(imgBordeSur, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 6: # linea vertical Norte
                pantalla.blit(imgBordeNor, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 5: # esquina superior derecha
                pantalla.blit(imgBordeEsqSupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 4: # esquina superior izquierda
                pantalla.blit(imgBordeEsqSupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 3: # esquina inferior derecha
                pantalla.blit(imgBordeEsqInfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 2: # esquina inferior izquierda
                pantalla.blit(imgBordeEsqInfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 1: # bloque de 1x1 Vacio
                pantalla.blit(imgBloqueVacio, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 0:
                pygame.draw.circle(pantalla, (255,255,255), (columna*ANCHO+9, fila*ALTO+9), 3)





while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_d:
                PacMan.posX += ANCHO
            elif event.key == pygame.K_a:
                PacMan.posX -= ANCHO
            elif event.key == pygame.K_w:
                PacMan.posY -= ALTO
            elif event.key == pygame.K_s:
                PacMan.posY += ALTO
    
    pantalla.fill("black")
    dibujarMatriz()

    #dibujar a pacman en la pantalla
    pantalla.blit(pacman, (PacMan.posX, PacMan.posY))

    reloj.tick(60)
    pygame.display.update()
