import pygame, sys, random
from tablero import tableroNiv1, tableroNiv2

# ----------------------------------------------------------- INICIALIZAR PYGAME -------------------------------------------------------

pygame.init()
pygame.mixer.init()
pantalla = pygame.display.set_mode((600, 700))
pygame.display.set_caption("Pac-Man")
reloj = pygame.time.Clock()
textoFuente = pygame.font.Font("Pixeltype.ttf", 50)

ANCHO = 18
ALTO = 18
MARGEN = 1
#horas 8 a 12 lunes 7
#martes 7 de 8 a 930 y de 12 a 1
#Miercoles de 10 a 3pm

# ----------------------------------------------------------- IMAGENES Y OBJETOS -------------------------------------------------------

# Fondo

# Entidades

# Jugador
imgJugadorArr = pygame.image.load("imagenes/pacman_nor.gif")
imgJugadorArr = pygame.transform.scale(imgJugadorArr, (18, 18))
imgJugadorDer = pygame.image.load("imagenes/pacman_est.gif")
imgJugadorDer = pygame.transform.scale(imgJugadorDer, (18, 18))
imgJugadorIzq = pygame.image.load("imagenes/pacman_oes.gif")
imgJugadorIzq = pygame.transform.scale(imgJugadorIzq, (18, 18))
imgJugadorAba = pygame.image.load("imagenes/pacman_sur.gif")
imgJugadorAba = pygame.transform.scale(imgJugadorAba, (18, 18))
imgJugadorMuere = pygame.image.load("imagenes/pacman_die.gif")
imgJugadorMuere = pygame.transform.scale(imgJugadorMuere, (18, 18))

# Enemigos
imgFantasmaVulnerable = pygame.image.load("imagenes/F1.gif")
imgFantasmaVulneFinal = pygame.image.load("imagenes/F1-2.gif")

    # Fantasma Naranja
imgFantasmaNaranjaArr = pygame.image.load("imagenes/Fnara_nor.gif")
imgFantasmaNaranjaAba = pygame.image.load("imagenes/Fnara_sur.gif")
imgFantasmaNaranjaDer = pygame.image.load("imagenes/Fnara_est.gif")
imgFantasmaNaranjaIzq = pygame.image.load("imagenes/Fnara_oes.gif")

    # Fantasma Rojo
imgFantasmaRojoArr = pygame.image.load("imagenes/Frojo_nor.gif")
imgFantasmaRojoAba = pygame.image.load("imagenes/Frojo_sur.gif")
imgFantasmaRojoDer = pygame.image.load("imagenes/Frojo_est.gif")
imgFantasmaRojoIzq = pygame.image.load("imagenes/Frojo_oes.gif")

    # Fantasma Celeste
imgFantasmaCelesteArr = pygame.image.load("imagenes/Fceles_nor.gif")
imgFantasmaCelesteAba = pygame.image.load("imagenes/Fceles_sur.gif")
imgFantasmaCelesteDer = pygame.image.load("imagenes/Fceles_est.gif")
imgFantasmaCelesteIzq = pygame.image.load("imagenes/Fceles_oes.gif")

    # Fantasma Rosa
imgFantasmaRosaArr = pygame.image.load("imagenes/Frosa_nor.gif")
imgFantasmaRosaAba = pygame.image.load("imagenes/Frosa_sur.gif")
imgFantasmaRosaDer = pygame.image.load("imagenes/Frosa_est.gif")
imgFantasmaRosaIzq = pygame.image.load("imagenes/Frosa_oes.gif")

# Frutas
imgFrutaCereza = pygame.image.load("imagenes/cereza.png")
imgFrutaManzana = pygame.image.load("imagenes/manzana.png")
imgFrutaNaranja = pygame.image.load("imagenes/naranja.png")
imgFrutaPera = pygame.image.load("imagenes/pera.png")
imgFrutaFresa = pygame.image.load("imagenes/fresa.png")

# Sonidos

# Escenario
imgBloqueVacio = pygame.image.load("Muros/Vacio.png") #Bloque Vacio
imgBloqueVacio = pygame.transform.scale(imgBloqueVacio, (18, 18))
imgBordeEst = pygame.image.load("Muros/Borde_E.png") #Borde Este
imgBordeEst = pygame.transform.scale(imgBordeEst, (18, 18))
imgBordeOes = pygame.image.load("Muros/Borde_O.png") #Borde Oeste
imgBordeOes = pygame.transform.scale(imgBordeOes, (18, 18))
imgBordeNor = pygame.image.load("Muros/Borde_N.png") #Borde Norte
imgBordeNor = pygame.transform.scale(imgBordeNor, (18, 18))
imgBordeSur = pygame.image.load("Muros/Borde_S.png") #Borde Sur
imgBordeSur = pygame.transform.scale(imgBordeSur, (18, 18))
imgBordeEsqSupDer = pygame.image.load("Muros/Esq_NE.png") #Esquina Superior Derecha
imgBordeEsqSupDer = pygame.transform.scale(imgBordeEsqSupDer, (18, 18))
imgBordeEsqSupIzq = pygame.image.load("Muros/Esq_NO.png") #Esquina Superior Izquierda
imgBordeEsqSupIzq = pygame.transform.scale(imgBordeEsqSupIzq, (18, 18))
imgBordeEsqInfDer = pygame.image.load("Muros/Esq_SE.png") #Esquina Inferior Derecha
imgBordeEsqInfDer = pygame.transform.scale(imgBordeEsqInfDer, (18, 18))
imgBordeEsqInfIzq = pygame.image.load("Muros/Esq_SO.png") #Esquina Inferior Izquierda
imgBordeEsqInfIzq = pygame.transform.scale(imgBordeEsqInfIzq, (18, 18))
imgBordeEsq2SupDer = pygame.image.load("Muros/Esq2_NE.png") #Esquina Pequenna Superior Derecha
imgBordeEsq2SupDer = pygame.transform.scale(imgBordeEsq2SupDer, (18, 18))
imgBordeEsq2SupIzq = pygame.image.load("Muros/Esq2_NO.png") #Esquina Pequenna Superior Izquierda
imgBordeEsq2SupIzq = pygame.transform.scale(imgBordeEsq2SupIzq, (18, 18))
imgBordeEsq2InfDer = pygame.image.load("Muros/Esq2_SE.png") #Esquina Pequenna Inferior Derecha
imgBordeEsq2InfDer = pygame.transform.scale(imgBordeEsq2InfDer, (18, 18))
imgBordeEsq2InfIzq = pygame.image.load("Muros/Esq2_SO.png") #Esquina Pequenna Inferior Izquierda
imgBordeEsq2InfIzq = pygame.transform.scale(imgBordeEsq2InfIzq, (18, 18))

#Nuevos escenarios
imgPiezaSup = pygame.image.load("Muros/Sup.png") #Pieza Superior
imgPiezaSup = pygame.transform.scale(imgPiezaSup, (18, 18))
imgPiezaInf = pygame.image.load("Muros/Inf.png") #Pierza Inferior
imgPiezaInf = pygame.transform.scale(imgPiezaInf, (18, 18))
imgPiezaIzq = pygame.image.load("Muros/Izq.png") #Pieza Izquierda
imgPiezaIzq = pygame.transform.scale(imgPiezaIzq, (18, 18))
imgPiezaDer = pygame.image.load("Muros/Der.png") #Pieza Derecha
imgPiezaDer = pygame.transform.scale(imgPiezaDer, (18, 18))
imgPiezaConec_NS = pygame.image.load("Muros/Conec_NS.png") #Pieza Conector Norte-Sur
imgPiezaConec_NS = pygame.transform.scale(imgPiezaConec_NS, (18, 18))
imgPiezaConec_NE = pygame.image.load("Muros/Conec_NE.png") #Pieza Conector Norte-Este
imgPiezaConec_NE = pygame.transform.scale(imgPiezaConec_NE, (18, 18))
imgPiezaConec_NO = pygame.image.load("Muros/Conec_NO.png") #Pieza Conector Norte-Oeste
imgPiezaConec_NO = pygame.transform.scale(imgPiezaConec_NO, (18, 18))
imgPiezaConec_SE = pygame.image.load("Muros/Conec_SE.png") #Pieza Conector Sur-Este
imgPiezaConec_SE = pygame.transform.scale(imgPiezaConec_SE, (18, 18))
imgPiezaConec_SO = pygame.image.load("Muros/Conec_SO.png") #Pieza Conector Sur-Oeste
imgPiezaConec_SO = pygame.transform.scale(imgPiezaConec_SO, (18, 18))
imgPiezaConec_OE = pygame.image.load("Muros/Conec_OE.png") #Pieza Conector Oeste-Este
imgPiezaConec_OE = pygame.transform.scale(imgPiezaConec_OE, (18, 18))
imgPiezaT = pygame.image.load("Muros/T.png") #Pieza Conector T
imgPiezaT = pygame.transform.scale(imgPiezaT, (18, 18))
imgPiezaT90 = pygame.image.load("Muros/T90.png") #Pieza Conector T90
imgPiezaT90 = pygame.transform.scale(imgPiezaT90, (18, 18))
imgPiezaT180 = pygame.image.load("Muros/T180.png") #Pieza Conector T180
imgPiezaT180 = pygame.transform.scale(imgPiezaT180, (18, 18))
imgPiezaT270 = pygame.image.load("Muros/T270.png") #Pieza Conector T270
imgPiezaT270 = pygame.transform.scale(imgPiezaT270, (18, 18))

pacman = pygame.image.load("pacman.png")
pacman = pygame.transform.scale(pacman, (ANCHO, ALTO))

pacmanTitulo = pygame.image.load("imagenes/titulopacman.png")

# ---------------------------------------------------------------- CLASES ------------------------------------------------------------
class Fondo:
    titulo = ""

    def __init__(self, titulo):
        self.titulo = titulo

    def dibFondo(self, pantalla):
        pantalla.blit(self.titulo,(300,50))

class Juego:
    nivel = 1
    nJuego = 0
    tablero = []
    score = 0
    PosP=[]

    def __init__(self, nivel, nJuego, tablero, score): 
        self.nivel = 1
        self.nJuego = 0
        self.tablero = tableroNiv1
        self.score = 0

    def get_tablero(self):
        return self.tablero

    def get_nivel(self):
        return self.nivel    

    def get_nJuego(self):
        return self.nJuego
        
    def get_score(self):
        return self.score
    
    def set_nivel(self, nivel):
        self.nivel = nivel

    def set_tablero(self, tablero):
        self.tablero = tablero  

    def set_nJuego(self, nJuego):
        self.nJuego = nJuego

    def set_score(self, score):
        self.score = score

    def iniciarJuego(self):
        return 0
    
    def subirNivel(self):
        if self.nivel == 1:
            self.tablero = tableroNiv1
        else:
            self.tablero = tableroNiv2

class PacMan:
    posY = 0
    posX = 0
    velMov = 0
    imgJugador = pacman
    EstadoE = False

    def __init__(self, posX, posY, velMov, imgJugador, EstadoE):
        self.posX = posX
        self.posY = posY
        self.velMov = 0
        self.EstadoE = False
        self.imgJugador = pacman

    def get_posX(self):
        return self.posX

    def get_posY(self):
        return self.posY

    def get_velMov(self):   
        return self.velMov
    
    def get_imgJugador(self):
        return self.imgJugador
    
    def get_EstadoE(self):
        return self.EstadoE

    def set_posX(self, posX):
        self.posX = posX

    def set_posY(self, posY):
        self.posY = posY

    def set_velMov(self, velMov):
        self.velMov = velMov

    def set_EstadoE(self, EstadoE):
        self.EstadoE = EstadoE

    def set_imgJugador(self, imgJugador):
        self.imgJugador = imgJugador

    def dibPantalla(self, pantalla):
        pantalla.blit(self.imgJugador,(self.posX, self.posY))

    def moverDere(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posX -= ANCHO
            Juego.check_collision(self)

    def moverIzq(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posX += ANCHO
            Juego.check_collision(self)
    
    def moverArr(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posY += ALTO
            Juego.check_collision(self)

    def moverAba(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posY -= ALTO
            Juego.check_collision(self)

    def comerFruta(self):
        Juego.score += 300
        return Juego.score
        
    def comerFantasma(self):
        Juego.score += 200
        return Juego.score
    

#     def check_collision(self, obj):
#         for i in listaPuntosBlancos:
#             if PacMan.posX ==   and obj.posY == dot.posY:
#                 self.score += 100
#                 self.white_dots.remove(dot)

class Fantasma:
    posX = 0
    posY = 0
    EstadoE = False
    velMov = 0
    Color = ""
    imgFantasma = ""


    def __init__(self, posX, posY, EstadoE, velMov, Color, imgFantasma):
        self.posX = posX
        self.posY = posY
        self.EstadoE = EstadoE
        self.velMov = velMov
        self.Color = Color
        self.imgFantasma = imgFantasma

    def get_posX(self):
        return self.posX

    def get_posY(self):
        return self.posY

    def get_EstadoE(self):
        return self.EstadoE
    
    def get_velMov(self):
        return self.velMov
    
    def get_Color(self):
        return self.Color
    
    def get_imgFantasma(self):
        return self.imgFantasma

    def set_posX(self, posX):
        self.posX = posX

    def set_posY(self, posY):
        self.posY = posY

    def set_EstadoE(self, EstadoE):
        self.EstadoE = EstadoE
    
    def set_velMov(self, velMov):
        self.velMov = velMov
    
    def set_Color(self, Color):
        self.Color = Color 

    def set_imgFantasma(self, imgFantasma):
        self.imgFantasma = imgFantasma

    def imagenFantasma(self):
        if self.Color == "Rojo":
            self.imgFantasma = imgFantasmaRojoDer
        elif self.Color == "Naranja":
            self.imgFantasma = imgFantasmaNaranjaDer
        elif self.Color == "Celeste":
            self.imgFantasma = imgFantasmaCelesteDer
        elif self.Color == "Rosa":
            self.imgFantasma = imgFantasmaRosaDer
    
    def velMovFantasma(self):
        if self.Color == "Rojo":
            self.velMov = 3
        elif self.Color == "Naranja":
            self.velMov = 2
        elif self.Color == "Celeste":
            self.velMov = 2
        elif self.Color == "Rosa":
            self.velMov = 2
    
    def dibPantalla(self, pantalla):
        pantalla.blit(self.imgFantasma,(self.posX, self.posY))
    
    def moverDere(self):
        if self.velMov == 2:
            self.posX += 2
        else:
            self.posX -= 2
    
    def moverIzq(self):
        if self.velMov == 2:
            self.posX -= 2
        else:
            self.posX += 2
    
    def moverArr(self):
        if self.velMov == 2:
            self.posY -= 2
        else:
            self.posY += 2

    def moverAba(self):
        if self.velMov == 2:
            self.posY += 2
        else:
            self.posY -= 2