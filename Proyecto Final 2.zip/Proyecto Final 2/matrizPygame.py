from PacmanBase import *

pygame.init()
pantalla = pygame.display.set_mode((650, 720))
pygame.display.set_caption("Ejemplo de matriz en Pygame")
reloj = pygame.time.Clock()

# Los valores que definen las dimensiones de las casillas
ANCHO = 18
ALTO = 18

juego = Juego(1,0,tablero_nivel_1,0)
matriz = juego.tablero
jugador = PacMan()
fantasmas = Fantasmas(juego.nivel)

inspeccionActiva = False
huboColision = False
muerte = False

def perder():
    fondoPerder = pygame.surface.Surface((200, 200))
    fondoPerder.fill("black")
    txtPerder = textoFuente.render(f"Puntos Finales: {juego.score}", False, "Yellow")
    txtPerder1 = textoFuente.render(f"Perdiste!", False, "Yellow") # Sirve para dibujar texto en pantalla
    pantalla.blit(fondoPerder, (70, 70))
    pantalla.blit(txtPerder, (100, 100))
    pantalla.blit(txtPerder1, (80, 80))

def dibujarInfoInspeccion():
    # Dibujar la informacion de los puntos
    fondoPts = pygame.surface.Surface((600, 500))
    fondoPts.fill("black")
    txtJueNiv = textoFuente.render(f"Nivel: {juego.nivel}", False, "Yellow")
    txtPuntos = textoFuente.render(f"Puntos: {juego.score}", False, "Yellow")
    txtJuegTab = textoFuente.render(f"Tablero: Tablero #1", False, "Yellow")
    txtJugPos = textoFuente.render(f"Posicion Jugador: {jugador.posX//ANCHO}, {jugador.posY//ALTO}", False, "Yellow")
    txtJugEstado = textoFuente.render(f"Estado Jugador: {jugador.EstadoE}", False, "Yellow")
    txtJugVel = textoFuente.render(f"Velocidad Jugador: {jugador.velMov}", False, "Yellow")
    txtFanPos = textoFuente.render(f"Posicion Fantasmas: {fantasmas.listaPosiciones}", False, "Yellow")
    txtFanNum = textoFuente.render(f"Numero Fantasmas: {len(fantasmas.listaFantasmas)}", False, "Yellow")
    pantalla.blit(fondoPts, (25, 50))
    pantalla.blit(txtJueNiv, (70, 80))
    pantalla.blit(txtPuntos, (70, 110))
    pantalla.blit(txtJuegTab, (70, 140))
    pantalla.blit(txtJugPos, (70, 170))
    pantalla.blit(txtJugEstado, (70, 200))
    pantalla.blit(txtJugVel, (70, 230))
    pantalla.blit(txtFanPos, (70, 260))
    pantalla.blit(txtFanNum, (70, 290))

def obtenerSigElemento(sigPosicion):
    sigPosY = sigPosicion[0]
    sigPosX = sigPosicion[1]
    return matriz[sigPosY//ALTO][sigPosX//ANCHO]

def moverfantasmas():
    for fantasma in fantasmas.listaFantasmas:
        if fantasma.direccion == 0:
            sigPosicion = [fantasma.posY, fantasma.posX+ANCHO]
            sigElemento = obtenerSigElemento(sigPosicion)
            if colisiones(sigElemento):
                fantasma.posX += ANCHO
            else:
                fantasma.direccionEscoger()
        elif fantasma.direccion == 1:
            sigPosicion = [fantasma.posY, fantasma.posX-ANCHO]
            sigElemento = obtenerSigElemento(sigPosicion)
            if colisiones(sigElemento):
                fantasma.posX -= ANCHO
            else:
                fantasma.direccionEscoger()
        elif fantasma.direccion == 2:
            sigPosicion = [fantasma.posY-ALTO, fantasma.posX]
            sigElemento = obtenerSigElemento(sigPosicion)
            if colisiones(sigElemento):
                fantasma.posY -= ALTO
            else:
                fantasma.direccionEscoger()
        elif fantasma.direccion == 3:
            sigPosicion = [fantasma.posY+ALTO, fantasma.posX]
            sigElemento = obtenerSigElemento(sigPosicion)
            if colisiones(sigElemento):
                fantasma.posY += ALTO
            else:
                fantasma.direccionEscoger()

def colisiones(sigElemento):
    if sigElemento == 0:
        return True
    elif sigElemento == 52:
        return True
    elif sigElemento == 53:
        return True
    elif sigElemento == 54:
        return True
    elif sigElemento == 55:
        return True
    elif sigElemento == 56:
        return True
    elif sigElemento == 324:
        return True
    elif sigElemento == 50:
        return True
    else:
        return False
    
def colisionesFantasmas(sigPosicion):
    if sigPosicion in fantasmas.listaPosiciones:
        muerte = True
    else:
        return False

# Dibujar la matriz. Esta funcion se corre dentro del game loop para actualizar el tablero
def dibujarMatriz():
    for fila in range(40):
        for columna in range(36):
            if matriz[fila][columna] == 56:
                pantalla.blit(imgFrutaNaranja, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 55:
                pantalla.blit(imgFrutaFresa, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 54:
                pantalla.blit(imgFrutaPera, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 53:
                pantalla.blit(imgFrutaManzana, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 52:
                pantalla.blit(imgFrutaCereza, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 51:
                pygame.draw.circle(pantalla, (255,255,255), (columna*ANCHO+9, fila*ALTO+9), 7)
            if matriz[fila][columna] == 50:
                pygame.draw.line(pantalla, "pink", (columna*ANCHO, fila*ALTO+9), (columna*ANCHO+18, fila*ALTO+9), 4)
            if matriz[fila][columna] == 27: #Pieza Conector T270
                pantalla.blit(imgPiezaT270, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 26: #Pieza Conector T180
                pantalla.blit(imgPiezaT180, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 25: #Pieza Conector T90
                pantalla.blit(imgPiezaT90, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 24: #Pieza Conector T
                pantalla.blit(imgPiezaT, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 23: #Pieza Conector Oeste-Este
                pantalla.blit(imgPiezaConec_OE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 22: #Pieza Conector Sur-Oeste
                pantalla.blit(imgPiezaConec_SO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 21: #Pieza Conector Sur-Este
                pantalla.blit(imgPiezaConec_SE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 20: #Pieza Conector Norte-Oeste
                pantalla.blit(imgPiezaConec_NO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 19: #Pieza Conector Norte-Este
                pantalla.blit(imgPiezaConec_NE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 18: #Pieza Conector Norte-Sur
                pantalla.blit(imgPiezaConec_NS, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 17: #Pieza Derecha
                pantalla.blit(imgPiezaDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 16: #Pieza Izquierda
                pantalla.blit(imgPiezaIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 15: #Pierza Inferior
                pantalla.blit(imgPiezaInf, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 14: #Pieza Superior
                pantalla.blit(imgPiezaSup, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 13: # esquina superior derecha
                pantalla.blit(imgBordeEsq2InfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 12: # esquina superior izquierda
                pantalla.blit(imgBordeEsq2SupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 11: # esquina inferior derecha
                pantalla.blit(imgBordeEsq2SupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 10: # esquina inferior izquierda
                pantalla.blit(imgBordeEsq2InfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 9: # linea vertical Oeste
                pantalla.blit(imgBordeOes, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 8: # linea horizontal Este
                pantalla.blit(imgBordeEst, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 7: # linea horizontal Sur
                pantalla.blit(imgBordeSur, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 6: # linea vertical Norte
                pantalla.blit(imgBordeNor, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 5: # esquina superior derecha
                pantalla.blit(imgBordeEsqSupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 4: # esquina superior izquierda
                pantalla.blit(imgBordeEsqSupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 3: # esquina inferior derecha
                pantalla.blit(imgBordeEsqInfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 2: # esquina inferior izquierda
                pantalla.blit(imgBordeEsqInfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 1: # bloque de 1x1 Vacio
                pantalla.blit(imgBloqueVacio, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 0:
                pygame.draw.circle(pantalla, (255,255,255), (columna*ANCHO+9, fila*ALTO+9), 3)

jugador.posX = 288
jugador.posY = 576
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key==pygame.K_SPACE:
                if inspeccionActiva:
                    inspeccionActiva = False
                else:
                    inspeccionActiva = True

            if inspeccionActiva == False: # Solo se pueden mover las piezas si la inspeccion esta desactivada
                huboColision = False
                if event.key == pygame.K_d:
                    sigPosicion = [jugador.posY, jugador.posX+ANCHO]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posX += ANCHO
                        pygame.mixer.music.load("Sonidos/WakaWaka.mp3")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(0.5)
                        if (jugador.posX % 10)/2 in [0,2,4,6,8]:
                            jugador.set_imgJugador(imgJugadorDer1)
                        else:
                            jugador.set_imgJugador(imgJugadorDer2)
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_a:
                    sigPosicion = [jugador.posY, jugador.posX-ANCHO]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posX -= ANCHO
                        pygame.mixer.music.load("Sonidos/WakaWaka.mp3")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(0.5)
                        if (jugador.posX % 10)/2 in [0,2,4,6,8]:
                            jugador.set_imgJugador(imgJugadorIzq1)
                        else:
                            jugador.set_imgJugador(imgJugadorIzq2)
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_w:
                    sigPosicion = [jugador.posY-ALTO, jugador.posX]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posY -= ALTO
                        pygame.mixer.music.load("Sonidos/WakaWaka.mp3")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(0.5)
                        if (jugador.posY % 10)/2 in [0,2,4,6,8]:
                            jugador.set_imgJugador(imgJugadorArr1)
                        else:
                            jugador.set_imgJugador(imgJugadorArr2)
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_s:
                    sigPosicion = [jugador.posY+ALTO, jugador.posX]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posY += ALTO
                        pygame.mixer.music.load("Sonidos/WakaWaka.mp3")
                        pygame.mixer.music.play(0)
                        pygame.mixer.music.set_volume(0.5)
                        if (jugador.posY % 10)/2 in [0,2,4,6,8]:
                            jugador.set_imgJugador(imgJugadorAba1)
                        else:
                            jugador.set_imgJugador(imgJugadorAba2)
                    colisionesFantasmas(sigPosicion)
                # Código para comer el alimento
                if huboColision and sigElemento == 0:
                    posPunto = [jugador.posY//ALTO, jugador.posX//ANCHO]
                    jugador.comerPunto(posPunto, juego)
                elif huboColision and sigElemento == 52 or sigElemento == 53 or sigElemento == 54 or sigElemento == 55 or sigElemento == 56:
                    posFruta = [jugador.posY//ALTO, jugador.posX//ANCHO]
                    jugador.comerFruta(posFruta, juego)
    
    pantalla.fill("black")
    dibujarMatriz()

    #dibujar a pacman en la pantalla
    pantalla.blit(jugador.imgJugador, (jugador.posX, jugador.posY))
    fantasmas.dibujarFantasmas(pantalla)
    fantasmas.obtenerPosiciones()
    moverfantasmas()
    
    if inspeccionActiva:
        dibujarInfoInspeccion()
    if muerte:
        perder()

    reloj.tick(60)
    pygame.display.update()
