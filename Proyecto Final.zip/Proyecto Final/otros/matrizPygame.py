import pygame, sys
from tablero import tableroNiv1, tableroNiv2
import PacmanBase

pygame.init()
pantalla = pygame.display.set_mode((700, 800))
pygame.display.set_caption("Ejemplo de matriz en Pygame")
reloj = pygame.time.Clock()
pantalla.fill("black")

# Los valores que definen las dimensiones de las casillas
ANCHO = 20
ALTO = 20
MARGEN = 1

# Crear la matriz
class Juego:
    nivel = 1

    def __init__(self, nivel):
        self.nivel = nivel

    def set_nivel(self, nivel):
        self.nivel = nivel

    def get_nivel(self):
        return self.nivel

# crear el objeto de la clase juego
juego = Juego(1)
juego.set_nivel(1)
nivel_actual = juego.get_nivel()
# asignar la matriz dependiendo del nivel
if nivel_actual == 1:
    matriz = tableroNiv1
else:
    matriz = tableroNiv2

# Dibujar la matriz. Esta funcion se corre dentro del game loop para actualizar el tablero
def dibujarMatriz():
    for fila in range(7):
        for columna in range(8):
            color = "white"
            if matriz[fila][columna] == 1:
                color = "black"
                #pantalla.blit(imgBloqueVacio, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 2:
                color = "red"
                #pantalla.blit(imgBordeNor, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 3:
                color = "blue"
                #pantalla.blit(imgBordeEsqSupIzq, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 4:
                color = "green"
                #pantalla.blit(imgBordeEsqSupDer, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 5:
                color = "yellow"
                #pantalla.blit(imgBordeEsqInfDer, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 6:
                color = "purple"
                #pantalla.blit(imgBordeEsqInfIzq, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 7:
                color = "orange"
                #pantalla.blit(imgBordeOes, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 8:
                color = "pink"
                #pantalla.blit(imgBordeSur, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            elif matriz[fila][columna] == 9:
                color = "cyan"
                #pantalla.blit(imgBordeEst, [(MARGEN + ANCHO) * columna + MARGEN, (MARGEN + ALTO) * fila + MARGEN])
            pygame.draw.rect(pantalla, color, [(MARGEN + ANCHO) * columna + MARGEN, # pos X
                                               (MARGEN + ALTO) * fila + MARGEN,     # pos Y
                                               ANCHO,                               # Ancho
                                               ALTO])                               # Alto

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.MOUSEBUTTONDOWN:
            # Obtener la posicion fila/columna de la casilla seleccionada usando el mouse
            pos = pygame.mouse.get_pos()
            columna = pos[0] // (ANCHO + MARGEN)
            fila = pos[1] // (ALTO + MARGEN)
            # Cambiar el valor de la casilla seleccionada
            matriz[fila][columna] = 1
            if fila == 3:
                matriz[fila][columna] = 2
            print("Click en la casilla: ", fila, columna)
    
    dibujarMatriz()

    reloj.tick(60)
    pygame.display.update()