def guardarDatosJugador():
    # Se abre el archivo de texto en modo de escritura
    archivo = open("scores.txt", "a")

    # Se escribe el nombre y el puntaje del jugador
    archivo.write(nombre + ", " + str(puntaje) + "\n")

    # Se cierra el archivo
    archivo.close()

def leerDatosJugador(nombre):
    # Se abre el archivo de texto en modo de lectura
    archivo = open("scores.txt", "r")

    # Se lee el archivo de texto
    for linea in archivo.readlines():
        # Se separa el nombre y el puntaje
        datos = linea.split(", ")

        # Se verifica si el nombre del jugador es igual al nombre del archivo
        if datos[0] == nombre:
            # Se cierra el archivo
            archivo.close()

            # Se retorna el puntaje del jugador
            return int(datos[1])

    # Se cierra el archivo
    archivo.close()

    # Se retorna 0 si no se encuentra el nombre del jugador
    return 0

def leerDatosJugadores():
    # Se abre el archivo de texto en modo de lectura
    archivo = open("scores.txt", "r")

    # Se crea una lista vacia para guardar los datos de los jugadores
    datosJugadores = []

    # Se lee el archivo de texto
    for linea in archivo.readlines():
        # Se separa el nombre y el puntaje
        datos = linea.split(", ")

        # Se agrega el nombre y el puntaje a la lista de datos de los jugadores
        datosJugadores.append([datos[0], int(datos[1])])

    # Se cierra el archivo
    archivo.close()

    # Se retorna la lista de datos de los jugadores
    return datosJugadores

def ordenarDatosJugadores(datosJugadores):
    # Se ordena la lista de datos de los jugadores
    datosJugadores.sort(key=lambda x: x[1], reverse=True)

    # Se sobreescribe el archivo de texto con la lista de datos de los jugadores ordenada
    sobreescribirDatosJugadores(datosJugadores)
    return datosJugadores

def sobreescribirDatosJugadores(datosJugadores):
    # Se abre el archivo de texto en modo de escritura
    archivo = open("scores.txt", "w")

    # Se escribe el nombre y el puntaje del jugador
    for datos in datosJugadores:
        archivo.write(datos[0] + ", " + str(datos[1]) + "\n")

    # Se cierra el archivo
    archivo.close()

def eliminarDatosJugadores():
    # Se abre el archivo de texto en modo de escritura
    archivo = open("scores.txt", "w")

    # Se cierra el archivo
    archivo.close()

# Variables de los jugadores
nombre = "Jugador 3"
puntaje = 6453

datos = leerDatosJugadores()
datos_ordenados = ordenarDatosJugadores(datos)
sobreescribirDatosJugadores(datos_ordenados)
