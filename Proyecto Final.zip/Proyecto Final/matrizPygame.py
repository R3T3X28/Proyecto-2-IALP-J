from PacmanBase import *

pygame.init()
pantalla = pygame.display.set_mode((650, 720))
pygame.display.set_caption("Ejemplo de matriz en Pygame")
reloj = pygame.time.Clock()

# Los valores que definen las dimensiones de las casillas
ANCHO = 18
ALTO = 18
listaPuntosBlancos = []

juego = Juego(1,0,tableroNiv1,0)
matriz = juego.tablero
jugador = PacMan()
fantasmas = Fantasmas(juego.nivel)

inspeccionActiva = False
huboColision = False

def dibujarInfoInspeccion():
    # Dibujar la informacion de los puntos
    fondoPts = pygame.surface.Surface((160, 100))
    fondoPts.fill("black")
    txtPuntos = textoFuente.render(f"Puntos: {juego.score}", False, "Brown") # Sirve para dibujar texto en pantalla
    pantalla.blit(fondoPts, (90, 90))
    pantalla.blit(txtPuntos, (100, 100))

def obtenerSigElemento(sigPosicion):
    sigPosY = sigPosicion[0]
    sigPosX = sigPosicion[1]
    return matriz[sigPosY//ALTO][sigPosX//ANCHO]

def colisiones(sigElemento):
    if sigElemento == 0:
        return True
    elif sigElemento == 324:
        return True
    else:
        return False
    
def colisionesFantasmas(sigPosicion):
    if sigPosicion in fantasmas.listaPosiciones:
        print("Colision con fantasma")
        return True
    else:
        return False

# Dibujar la matriz. Esta funcion se corre dentro del game loop para actualizar el tablero
def dibujarMatriz():
    for fila in range(40):
        for columna in range(36):
            if matriz[fila][columna] == 27: #Pieza Conector T270
                pantalla.blit(imgPiezaT270, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 26: #Pieza Conector T180
                pantalla.blit(imgPiezaT180, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 25: #Pieza Conector T90
                pantalla.blit(imgPiezaT90, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 24: #Pieza Conector T
                pantalla.blit(imgPiezaT, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 23: #Pieza Conector Oeste-Este
                pantalla.blit(imgPiezaConec_OE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 22: #Pieza Conector Sur-Oeste
                pantalla.blit(imgPiezaConec_SO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 21: #Pieza Conector Sur-Este
                pantalla.blit(imgPiezaConec_SE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 20: #Pieza Conector Norte-Oeste
                pantalla.blit(imgPiezaConec_NO, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 19: #Pieza Conector Norte-Este
                pantalla.blit(imgPiezaConec_NE, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 18: #Pieza Conector Norte-Sur
                pantalla.blit(imgPiezaConec_NS, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 17: #Pieza Derecha
                pantalla.blit(imgPiezaDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 16: #Pieza Izquierda
                pantalla.blit(imgPiezaIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 15: #Pierza Inferior
                pantalla.blit(imgPiezaInf, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 14: #Pieza Superior
                pantalla.blit(imgPiezaSup, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 13: # esquina superior derecha
                pantalla.blit(imgBordeEsq2InfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 12: # esquina superior izquierda
                pantalla.blit(imgBordeEsq2SupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 11: # esquina inferior derecha
                pantalla.blit(imgBordeEsq2SupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 10: # esquina inferior izquierda
                pantalla.blit(imgBordeEsq2InfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 9: # linea vertical Oeste
                pantalla.blit(imgBordeOes, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 8: # linea horizontal Este
                pantalla.blit(imgBordeEst, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 7: # linea horizontal Sur
                pantalla.blit(imgBordeSur, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 6: # linea vertical Norte
                pantalla.blit(imgBordeNor, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 5: # esquina superior derecha
                pantalla.blit(imgBordeEsqSupDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 4: # esquina superior izquierda
                pantalla.blit(imgBordeEsqSupIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 3: # esquina inferior derecha
                pantalla.blit(imgBordeEsqInfDer, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 2: # esquina inferior izquierda
                pantalla.blit(imgBordeEsqInfIzq, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 1: # bloque de 1x1 Vacio
                pantalla.blit(imgBloqueVacio, (columna*ANCHO, fila*ALTO))
            if matriz[fila][columna] == 0:
                pygame.draw.circle(pantalla, (255,255,255), (columna*ANCHO+9, fila*ALTO+9), 3)
                #listaPuntosBlancos.append((fila,columna))

jugador.posX = 288
jugador.posY = 576
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key==pygame.K_SPACE:
                if inspeccionActiva:
                    inspeccionActiva = False
                else:
                    inspeccionActiva = True

            if inspeccionActiva == False: # Solo se pueden mover las piezas si la inspeccion esta desactivada
                huboColision = False
                if event.key == pygame.K_d:
                    sigPosicion = [jugador.posY, jugador.posX+ANCHO]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posX += ANCHO
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_a:
                    sigPosicion = [jugador.posY, jugador.posX-ANCHO]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posX -= ANCHO
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_w:
                    sigPosicion = [jugador.posY-ALTO, jugador.posX]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posY -= ALTO
                    colisionesFantasmas(sigPosicion)
                elif event.key == pygame.K_s:
                    sigPosicion = [jugador.posY+ALTO, jugador.posX]
                    sigElemento = obtenerSigElemento(sigPosicion)
                    if colisiones(sigElemento):
                        huboColision = True
                        jugador.posY += ALTO
                    colisionesFantasmas(sigPosicion)
                # Código para comer el alimento
                if huboColision and sigElemento == 0:
                    posFruta = [jugador.posY//ALTO, jugador.posX//ANCHO]
                    jugador.comerFruta(posFruta, juego)
    
    pantalla.fill("black")
    dibujarMatriz()

    #dibujar a pacman en la pantalla
    pantalla.blit(jugador.imgJugador, (jugador.posX, jugador.posY))
    fantasmas.dibujarFantasmas(pantalla)
    fantasmas.obtenerPosiciones()
    
    if inspeccionActiva:
        dibujarInfoInspeccion()

    reloj.tick(60)
    pygame.display.update()
