import pygame, sys, random
from tablero import tableroNiv1, tableroNiv2

# ----------------------------------------------------------- INICIALIZAR PYGAME -------------------------------------------------------

pygame.init()
pygame.mixer.init()
pantalla = pygame.display.set_mode((600, 700))
pygame.display.set_caption("Pac-Man")
reloj = pygame.time.Clock()
textoFuente = pygame.font.Font("Pixeltype.ttf", 50)

ANCHO = 18
ALTO = 18
MARGEN = 1
#horas 8 a 12 lunes 6
#martes 7e de 8 a 930 y de 12 a 1 pm
#Miercoles de 10 a 3 pm
#viernes de 4 a

# ----------------------------------------------------------- IMAGENES Y OBJETOS -------------------------------------------------------

# Fondo


# Entidades

# Jugador
imgJugadorArr1 = pygame.image.load("imagenes/PacMan_N1.png")
imgJugadorArr1 = pygame.transform.scale(imgJugadorArr1, (18, 18))
imgJugadorArr2 = pygame.image.load("imagenes/PacMan_N2.png")
imgJugadorArr2 = pygame.transform.scale(imgJugadorArr2, (18, 18))
imgJugadorDer1 = pygame.image.load("imagenes/PacMan_E1.png")
imgJugadorDer1 = pygame.transform.scale(imgJugadorDer1, (18, 18))
imgJugadorDer2 = pygame.image.load("imagenes/PacMan_E2.png")
imgJugadorDer2 = pygame.transform.scale(imgJugadorDer2, (18, 18))
imgJugadorIzq1 = pygame.image.load("imagenes/PacMan_O1.png")
imgJugadorIzq1 = pygame.transform.scale(imgJugadorIzq1, (18, 18))
imgJugadorIzq2 = pygame.image.load("imagenes/PacMan_O2.png")
imgJugadorIzq2 = pygame.transform.scale(imgJugadorIzq2, (18, 18))
imgJugadorAba1 = pygame.image.load("imagenes/PacMan_S1.png")
imgJugadorAba1 = pygame.transform.scale(imgJugadorAba1, (18, 18))
imgJugadorAba2 = pygame.image.load("imagenes/PacMan_S2.png")
imgJugadorAba2 = pygame.transform.scale(imgJugadorAba2, (18, 18))
imgJugadorMuere1 = pygame.image.load("imagenes/PacMan_Dead1.png")
imgJugadorMuere1 = pygame.transform.scale(imgJugadorMuere1, (18, 18))
imgJugadorMuere2 = pygame.image.load("imagenes/PacMan_Dead2.png")
imgJugadorMuere2 = pygame.transform.scale(imgJugadorMuere2, (18, 18))
imgJugadorMuere3 = pygame.image.load("imagenes/PacMan_Dead3.png")
imgJugadorMuere3 = pygame.transform.scale(imgJugadorMuere3, (18, 18))

# Enemigos
imgFantasmaVulnerable1 = pygame.image.load("imagenes/FDebil_1.png")
imgFantasmaVulnerable1 = pygame.transform.scale(imgFantasmaVulnerable1, (18, 18))
imgFantasmaVulnerable2 = pygame.image.load("imagenes/FDebil_2.png")
imgFantasmaVulnerable2 = pygame.transform.scale(imgFantasmaVulnerable2, (18, 18))
imgFantasmaVulneFinal1 = pygame.image.load("imagenes/FDebil_3.png")
imgFantasmaVulneFinal1 = pygame.transform.scale(imgFantasmaVulneFinal1, (18, 18))
imgFantasmaVulneFinal2 = pygame.image.load("imagenes/FDebil_4.png")
imgFantasmaVulneFinal2 = pygame.transform.scale(imgFantasmaVulneFinal2, (18, 18))

    # Fantasma Naranja
imgFantasmaNaranjaArr = pygame.image.load("imagenes/Fnara_nor.gif")
imgFantasmaNaranjaAba = pygame.image.load("imagenes/Fnara_sur.gif")
imgFantasmaNaranjaDer = pygame.image.load("imagenes/Fnara_est.gif")
imgFantasmaNaranjaIzq = pygame.image.load("imagenes/Fnara_oes.gif")

    # Fantasma Rojo
imgFantasmaRojoArr = pygame.image.load("imagenes/Frojo_nor.gif")
imgFantasmaRojoAba = pygame.image.load("imagenes/Frojo_sur.gif")
imgFantasmaRojoDer = pygame.image.load("imagenes/Frojo_est.gif")
imgFantasmaRojoIzq = pygame.image.load("imagenes/Frojo_oes.gif")

    # Fantasma Celeste
imgFantasmaCelesteArr = pygame.image.load("imagenes/Fceles_nor.gif")
imgFantasmaCelesteAba = pygame.image.load("imagenes/Fceles_sur.gif")
imgFantasmaCelesteDer = pygame.image.load("imagenes/Fceles_est.gif")
imgFantasmaCelesteIzq = pygame.image.load("imagenes/Fceles_oes.gif")

    # Fantasma Rosa
imgFantasmaRosaArr = pygame.image.load("imagenes/Frosa_nor.gif")
imgFantasmaRosaArr = pygame.transform.scale(imgFantasmaRosaArr, (28, 28))
imgFantasmaRosaAba = pygame.image.load("imagenes/Frosa_sur.gif")
imgFantasmaRosaAba = pygame.transform.scale(imgFantasmaRosaAba, (28, 28))
imgFantasmaRosaDer = pygame.image.load("imagenes/Frosa_est.gif")
imgFantasmaRosaDer = pygame.transform.scale(imgFantasmaRosaDer, (28, 28))
imgFantasmaRosaIzq = pygame.image.load("imagenes/Frosa_oes.gif")
imgFantasmaRosaIzq = pygame.transform.scale(imgFantasmaRosaIzq, (28, 28))


# Frutas
imgFrutaCereza = pygame.image.load("imagenes/cereza.png")
imgFrutaManzana = pygame.image.load("imagenes/manzana.png")
imgFrutaNaranja = pygame.image.load("imagenes/naranja.png")
imgFrutaPera = pygame.image.load("imagenes/pera.png")
imgFrutaFresa = pygame.image.load("imagenes/fresa.png")

# Sonidos

# Escenario
imgBloqueVacio = pygame.image.load("Muros/Vacio.png") #Bloque Vacio
imgBloqueVacio = pygame.transform.scale(imgBloqueVacio, (18, 18))
imgBordeEst = pygame.image.load("Muros/Borde_E.png") #Borde Este
imgBordeEst = pygame.transform.scale(imgBordeEst, (18, 18))
imgBordeOes = pygame.image.load("Muros/Borde_O.png") #Borde Oeste
imgBordeOes = pygame.transform.scale(imgBordeOes, (18, 18))
imgBordeNor = pygame.image.load("Muros/Borde_N.png") #Borde Norte
imgBordeNor = pygame.transform.scale(imgBordeNor, (18, 18))
imgBordeSur = pygame.image.load("Muros/Borde_S.png") #Borde Sur
imgBordeSur = pygame.transform.scale(imgBordeSur, (18, 18))
imgBordeEsqSupDer = pygame.image.load("Muros/Esq_NE.png") #Esquina Superior Derecha
imgBordeEsqSupDer = pygame.transform.scale(imgBordeEsqSupDer, (18, 18))
imgBordeEsqSupIzq = pygame.image.load("Muros/Esq_NO.png") #Esquina Superior Izquierda
imgBordeEsqSupIzq = pygame.transform.scale(imgBordeEsqSupIzq, (18, 18))
imgBordeEsqInfDer = pygame.image.load("Muros/Esq_SE.png") #Esquina Inferior Derecha
imgBordeEsqInfDer = pygame.transform.scale(imgBordeEsqInfDer, (18, 18))
imgBordeEsqInfIzq = pygame.image.load("Muros/Esq_SO.png") #Esquina Inferior Izquierda
imgBordeEsqInfIzq = pygame.transform.scale(imgBordeEsqInfIzq, (18, 18))
imgBordeEsq2SupDer = pygame.image.load("Muros/Esq2_NE.png") #Esquina Pequenna Superior Derecha
imgBordeEsq2SupDer = pygame.transform.scale(imgBordeEsq2SupDer, (18, 18))
imgBordeEsq2SupIzq = pygame.image.load("Muros/Esq2_NO.png") #Esquina Pequenna Superior Izquierda
imgBordeEsq2SupIzq = pygame.transform.scale(imgBordeEsq2SupIzq, (18, 18))
imgBordeEsq2InfDer = pygame.image.load("Muros/Esq2_SE.png") #Esquina Pequenna Inferior Derecha
imgBordeEsq2InfDer = pygame.transform.scale(imgBordeEsq2InfDer, (18, 18))
imgBordeEsq2InfIzq = pygame.image.load("Muros/Esq2_SO.png") #Esquina Pequenna Inferior Izquierda
imgBordeEsq2InfIzq = pygame.transform.scale(imgBordeEsq2InfIzq, (18, 18))

#Nuevos escenarios
imgPiezaSup = pygame.image.load("Muros/Sup.png") #Pieza Superior
imgPiezaSup = pygame.transform.scale(imgPiezaSup, (18, 18))
imgPiezaInf = pygame.image.load("Muros/Inf.png") #Pierza Inferior
imgPiezaInf = pygame.transform.scale(imgPiezaInf, (18, 18))
imgPiezaIzq = pygame.image.load("Muros/Izq.png") #Pieza Izquierda
imgPiezaIzq = pygame.transform.scale(imgPiezaIzq, (18, 18))
imgPiezaDer = pygame.image.load("Muros/Der.png") #Pieza Derecha
imgPiezaDer = pygame.transform.scale(imgPiezaDer, (18, 18))
imgPiezaConec_NS = pygame.image.load("Muros/Conec_NS.png") #Pieza Conector Norte-Sur
imgPiezaConec_NS = pygame.transform.scale(imgPiezaConec_NS, (18, 18))
imgPiezaConec_NE = pygame.image.load("Muros/Conec_NE.png") #Pieza Conector Norte-Este
imgPiezaConec_NE = pygame.transform.scale(imgPiezaConec_NE, (18, 18))
imgPiezaConec_NO = pygame.image.load("Muros/Conec_NO.png") #Pieza Conector Norte-Oeste
imgPiezaConec_NO = pygame.transform.scale(imgPiezaConec_NO, (18, 18))
imgPiezaConec_SE = pygame.image.load("Muros/Conec_SE.png") #Pieza Conector Sur-Este
imgPiezaConec_SE = pygame.transform.scale(imgPiezaConec_SE, (18, 18))
imgPiezaConec_SO = pygame.image.load("Muros/Conec_SO.png") #Pieza Conector Sur-Oeste
imgPiezaConec_SO = pygame.transform.scale(imgPiezaConec_SO, (18, 18))
imgPiezaConec_OE = pygame.image.load("Muros/Conec_OE.png") #Pieza Conector Oeste-Este
imgPiezaConec_OE = pygame.transform.scale(imgPiezaConec_OE, (18, 18))
imgPiezaT = pygame.image.load("Muros/T.png") #Pieza Conector T
imgPiezaT = pygame.transform.scale(imgPiezaT, (18, 18))
imgPiezaT90 = pygame.image.load("Muros/T90.png") #Pieza Conector T90
imgPiezaT90 = pygame.transform.scale(imgPiezaT90, (18, 18))
imgPiezaT180 = pygame.image.load("Muros/T180.png") #Pieza Conector T180
imgPiezaT180 = pygame.transform.scale(imgPiezaT180, (18, 18))
imgPiezaT270 = pygame.image.load("Muros/T270.png") #Pieza Conector T270
imgPiezaT270 = pygame.transform.scale(imgPiezaT270, (18, 18))

pacman = pygame.image.load("pacman.png")
pacman = pygame.transform.scale(pacman, (ANCHO, ALTO))

pacmanTitulo = pygame.image.load("imagenes/titulopacman.png")

# ---------------------------------------------------------------- CLASES ------------------------------------------------------------
class Fondo:
    titulo = ""

    def __init__(self, titulo):
        self.titulo = titulo

    def dibFondo(self, pantalla):
        pantalla.blit(self.titulo,(300,50))

class Juego:
    nivel = 1
    nJuego = 0
    tablero = []
    score = 0
    PosP=[]

    def __init__(self, nivel, nJuego, tablero, score): 
        self.nivel = 1
        self.nJuego = 0
        self.tablero = tableroNiv1
        self.score = 0

    def get_tablero(self):
        return self.tablero

    def get_nivel(self):
        return self.nivel    

    def get_nJuego(self):
        return self.nJuego
        
    def get_score(self):
        return self.score
    
    def set_nivel(self, nivel):
        self.nivel = nivel

    def set_tablero(self, tablero):
        self.tablero = tablero  

    def set_nJuego(self, nJuego):
        self.nJuego = nJuego

    def set_score(self, score):
        self.score = score

    def iniciarJuego(self):
        return 0
    
    def subirNivel(self):
        if self.nivel == 1:
            self.tablero = tableroNiv1
        else:
            self.tablero = tableroNiv2

class PacMan:
    posY = 0
    posX = 0
    velMov = 0
    imgJugador = pacman
    EstadoE = False

    def __init__(self):
        self.posX = 1
        self.posY = 1
        self.velMov = 0
        self.EstadoE = False
        self.imgJugador = pacman

    def get_posX(self):
        return self.posX

    def get_posY(self):
        return self.posY

    def get_velMov(self):   
        return self.velMov
    
    def get_imgJugador(self):
        return self.imgJugador
    
    def get_EstadoE(self):
        return self.EstadoE

    def set_posX(self, posX):
        self.posX = posX

    def set_posY(self, posY):
        self.posY = posY

    def set_velMov(self, velMov):
        self.velMov = velMov

    def set_EstadoE(self, EstadoE):
        self.EstadoE = EstadoE

    def set_imgJugador(self, imgJugador):
        self.imgJugador = imgJugador

    def dibPantalla(self, pantalla):
        pantalla.blit(self.imgJugador,(self.posX, self.posY))

    def moverDere(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posX -= ANCHO
            Juego.check_collision(self)

    def moverIzq(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posX += ANCHO
            Juego.check_collision(self)
    
    def moverArr(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posY += ALTO
            Juego.check_collision(self)

    def moverAba(self):
        if self.velMov == 1 or self.velMov == 2:
            self.posY -= ALTO
            Juego.check_collision(self)

    def comerFruta(self, posFruta, juego):
        juego.score += 300
        juego.tablero[posFruta[0]][posFruta[1]] = 324
        return juego.score
        
    def comerFantasma(self):
        Juego.score += 200
        return Juego.score
    

#     def check_collision(self, obj):
#         for i in listaPuntosBlancos:
#             if PacMan.posX ==   and obj.posY == dot.posY:
#                 self.score += 100
#                 self.white_dots.remove(dot)

class Fantasma:
    posX = 0
    posY = 0
    estadoE = False
    velMov = 0
    color = ""
    imgFantasma = ""


    def __init__(self, posX, posY, numFantasma):
        self.posX = posX
        self.posY = posY
        self.estadoE = False
        # Determinar el color de acuerdo al numero de fantasma
        if numFantasma % 4 == 0:
            self.color = "Rojo"
        elif numFantasma % 4 == 1:
            self.color = "Naranja"
        elif numFantasma % 4 == 2:
            self.color = "Celeste"
        elif numFantasma % 4 == 3:
            self.color = "Rosa"
        self.imagenFantasma()
        self.velMovFantasma()

    def get_posX(self):
        return self.posX

    def get_posY(self):
        return self.posY

    def get_EstadoE(self):
        return self.estadoE
    
    def get_velMov(self):
        return self.velMov
    
    def get_Color(self):
        return self.color
    
    def get_imgFantasma(self):
        return self.imgFantasma

    def set_posX(self, posX):
        self.posX = posX

    def set_posY(self, posY):
        self.posY = posY

    def set_EstadoE(self, EstadoE):
        self.estadoE = EstadoE
    
    def set_velMov(self, velMov):
        self.velMov = velMov
    
    def set_Color(self, Color):
        self.color = Color 

    def set_imgFantasma(self, imgFantasma):
        self.imgFantasma = imgFantasma

    def imagenFantasma(self):
        if self.color == "Rojo":
            self.imgFantasma = imgFantasmaRojoDer
        elif self.color == "Naranja":
            self.imgFantasma = imgFantasmaNaranjaDer
        elif self.color == "Celeste":
            self.imgFantasma = imgFantasmaCelesteDer
        elif self.color == "Rosa":
            self.imgFantasma = imgFantasmaRosaDer
    
    def velMovFantasma(self):
        if self.color == "Rojo":
            self.velMov = 3
        elif self.color == "Naranja":
            self.velMov = 2
        elif self.color == "Celeste":
            self.velMov = 2
        elif self.color == "Rosa":
            self.velMov = 2
    
    def dibPantalla(self, pantalla):
        pantalla.blit(self.imgFantasma,(self.posX, self.posY))
    
    def moverDere(self):
        if self.velMov == 2:
            self.posX += 2
        else:
            self.posX -= 2
    
    def moverIzq(self):
        if self.velMov == 2:
            self.posX -= 2
        else:
            self.posX += 2
    
    def moverArr(self):
        if self.velMov == 2:
            self.posY -= 2
        else:
            self.posY += 2

    def moverAba(self):
        if self.velMov == 2:
            self.posY += 2
        else:
            self.posY -= 2

class Fantasmas:
    listaFantasmas = []
    listaPosiciones = []

    def __init__(self, numNivel):
        if numNivel == 1:
            numFantasmas = 4
            posX = 288
        else:
            numFantasmas = 6
            posX = 270
        for i in range(numFantasmas):
            self.listaFantasmas.append(Fantasma(posX, 270, i))
            posX += ANCHO

    def agregarFantasma(self, fantasma):
        self.listaFantasmas.append(fantasma)

    def eliminarFantasma(self, fantasma):
        self.listaFantasmas.remove(fantasma)

    def obtenerPosiciones(self):
        posiciones = []
        for fantasma in self.listaFantasmas:
            posiciones.append([fantasma.get_posY(), fantasma.get_posX()])
        self.listaPosiciones = posiciones
        return posiciones
    
    def dibujarFantasmas(self, pantalla):
        for fantasma in self.listaFantasmas:
            fantasma.dibPantalla(pantalla)
